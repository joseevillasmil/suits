<?php
/*
* Simple Login jose villasmil
*/
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\Account;
use App\Models\Credit;

class CreditController extends Controller
{

	public function index()
	{
			#The first view in the application 
			#After login.
			
			$accounts = Account::orderBy('name')->get();
			
			$datos = array(
				"accounts" => $accounts,
			);
			
			$view = view('panel/index')->with($datos);
			return $view;
	}
	
	public function postCredit(Request $request, $accountId)
	{	
		
		$account = Account::find($accountId);
		
		#Lets set a simply validation :)
		$error = "";
		if(empty($account))
			$error = "Operacion no disponible";
		
		if(!is_numeric($request->amount))
			$error = "Monto no valido";
		
		elseif($request->amount <= 0)
			$error = "Monto no permitido";
		
		#Error found :(
		if(!empty($error))
			return response()->json([
					'state' => 'success',
					'alert' => array (
								      'type' => 'danger', 
									  'message' => $error
								),
				]);
		
		#If everything is fine :)
		#Process the transaction
		$credit = new Credit();
		$credit->account_id = $accountId;
		$credit->amount = $request->amount;
		$credit->description = $request->description;
		$credit->currency_id = $account->currency_id;
		$credit->save();
		
		#Debit the amount to the account
		
		$account->balance = $account->balance + $request->amount;
		$account->save();
		
		#return the result of the trans.
			$datos = array(
				"account" => $account,
			);
			
			$view = view('panel/account')->with($datos);
			
			return response()->json([
					'state' => 'success',
					'html' => $view->render(),
					'alert' => array (
								      'type' => 'success', 
									  'message' => 'Registro exitoso'
								),
				]);
	}
	
	
}
