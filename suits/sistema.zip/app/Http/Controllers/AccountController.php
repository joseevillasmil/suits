<?php
/*
* Simple Login jose villasmil
*/
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\Account;
use App\Models\Bill;

class AccountController extends Controller
{

	public function index()
	{
			
			$accounts = Account::orderBy('name')->get();
			
			$view = view('panel/accounts', [ "accounts" => $accounts ])->render();
			
			
			return response()->json([
					'state' => 'success',
					'html' => $view,
				]);
				
	}
	
	public function getAccount($id)
	{
			$account = Account::find($id);
			$bills = Bill::orderBy('name')->get();
			
			$datos = array(
				"account" => $account,
				"bills" => $bills,
			);
			
			$view = view('panel/account')->with($datos);
			
			return response()->json([
					'state' => 'success',
					'html' => $view->render(),
				]);
				
	}
	
	
}
