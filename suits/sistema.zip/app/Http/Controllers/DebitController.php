<?php
/*
* Simple Login jose villasmil
*/
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\Debit;
use App\Models\Bill;
use App\Models\Account;

class DebitController extends Controller
{

	public function index()
	{
			#The first view in the application 
			#After login.
			
			$accounts = Account::orderBy('name')->get();
			
			$datos = array(
				"accounts" => $accounts,
			);
			
			$view = view('panel/index')->with($datos);
			return $view;
	}
	
	public function postDebit(Request $request, $accountId)
	{	
		
		$account = Account::find($accountId);
		
		#Lets set a simply validation :)
		$error = "";
		if(empty($account))
			$error = "Operacion no disponible";
		
		if(!is_numeric($request->amount))
			$error = "Monto no valido";
		
		elseif($request->amount > $account->balance or $request->amount <= 0)
			$error = "Monto no permitido";
		
		#Error found :(
		if(!empty($error))
			return response()->json([
					'state' => 'success',
					'alert' => array (
								      'type' => 'danger', 
									  'message' => $error
								),
				]);
		
		#If everything is fine :)
		#Process the transaction
		$debit = new Debit();
		$debit->account_id = $accountId;
		$debit->amount = $request->amount;
		$debit->description = $request->description;
		$debit->bill_id = $request->bill_id;
		$debit->currency_id = $account->currency_id;
		$debit->save();
		
		#Debit the amount to the account
		
		$account->balance = $account->balance - $request->amount;
		$account->save();
		
		#return the result of the trans.
		$bills = Bill::orderBy('name')->get();
		
			$datos = array(
				"account" => $account,
				"bills" => $bills,
			);
			
			$view = view('panel/account')->with($datos);
			
			return response()->json([
					'state' => 'success',
					'html' => $view->render(),
					'alert' => array (
								      'type' => 'success', 
									  'message' => 'Registro exitoso'
								),
				]);
	}
	
	
}
