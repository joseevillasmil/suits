<?php
/*
* Simple Bills Controller jose villasmil
*/
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\Bill;

class BillController extends Controller
{

	public function index()
	{
			
			$debits = Bill::orderBy('name')->get();
			
			$view = view('panel/bills', [ "bills" => $debits ])->render();
			
			
			return response()->json([
					'state' => 'success',
					'html' => $view,
				]);
				
	}
	
	public function postNew(Request $request)
	{	
	
		#Process the transaction
		$debit = new Bill();
		$debit->name = $request->name;
		$debit->description = $request->description;
		$debit->save();
		
		#Returning information plus an alert.
		
		$debits = Bill::orderBy('name')->get();
		$view = view('panel/bills', [ "bills" => $debits ])->render();
			
			return response()->json([
					'state' => 'success',
					'html' => $view,
					'alert' => array (
								      'type' => 'success', 
									  'message' => 'Registro exitoso'
								),
				]);
	}
	
}
