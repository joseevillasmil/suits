<?php
/*
* Simple Login jose villasmil
*/
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\Account;

class IndexController extends Controller
{

	public function index()
	{
			#The first view in the application 
			#After login.
			
			$accounts = Account::orderBy('name')->get();
			
			$datos = array(
				"accounts" => $accounts,
			);
			
			$view = view('panel/index')->with($datos);
			return $view;
	}
	
	
}
