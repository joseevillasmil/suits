<?php
/*
* Simple Login jose villasmil
*/
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\Currency;

class CurrencyController extends Controller
{

	public function getCurrencys()
	{
			$currencys = Currency::orderBy('name')->get();
			
			$datos = array(
				"currencys" => $currencys,
			);
			
			$view = view('panel/currencys')->with($datos);
			
			return response()->json([
					'state' => 'success',
					'html' => $view->render(),
				]);
				
	}
	
	
	public function postEdit(Request $request, $id)
	{	
		#Lets do a simple validation.
		
		if($request->value>0)
			$value = round(1/$request->value,12);
		else
			$value = 0;
		
		$currency = Currency::find($id);
		$currency->value = $value;
		$currency->save();
			
		#lets render view to the app
		
		$currencys = Currency::orderBy('name')->get();
			
			$datos = array(
				"currencys" => $currencys,
			);
			
			$view = view('panel/currencys')->with($datos);
			
			return response()->json([
					'state' => 'success',
					'html' => $view->render(),
					'alert' => array (
								      'type' => 'success', 
									  'message' => 'Moneda editada con exito'
								),
				]);
	
	}
	
	
}
