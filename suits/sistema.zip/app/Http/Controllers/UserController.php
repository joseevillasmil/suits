<?php
/*
* Simple Login jose villasmil
*/
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\Empresa;
use Auth;
use session;

class UserController extends Controller
{

	function postLogin(Request $Request){
		
		$email = $Request->email;
		$password = $Request->password;
		
		if (Auth::attempt(['email' => $email, 'password' => $password,  'deleted_at' => null]))
			{
				session([ "email" => $email ]);
				$view = view('cuenta/success');
				
				
				#when it is all ok.
				return response()->json([
					'state' => 'success',
					'html' => $view->render(),
					'location' => route('index'),
					'alert' => array (
								      'type' => 'success', 
									  'message' => 'Inicio de sesión exitoso'
								),
				]);
				
			}
			
		#In case of failure
		return response()->json([
					'state' => 'fail',
					'alert' => array (
								      'type' => 'danger', 
									  'message' => 'Usuario y/o contraseña invalido(s)'
								),
					
				]);
		
		
	}
	
	
	#Simple function logOut.
	
	function getLogOut()
	{
		Auth::logout();
		
		#Lets return to the view.
				return response()->json([
					'state' => 'success',
					'location' => route('login'),
					'alert' => array (
								      'type' => 'success', 
									  'message' => 'Sesion finalizada'
								),
				]);
	}

	
	
}
