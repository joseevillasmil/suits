<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Debit extends Model
{
	use SoftDeletes;
	
	protected $table ="debits";

	function account()
	{
		return $this->belongsTo('App\Models\Account', 'account_id');
	}
	
	function bill()
	{
		return $this->belongsTo('App\Models\Bill', 'bill_id');
	}
	

}