<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Bill extends Model
{
	use SoftDeletes;
	
	protected $table ="bills";

	function debits()
	{
		return $this->hasMany('App\Models\Debit', 'bill_id');
	}
	

}