<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Account extends Model
{
	use SoftDeletes;
	
	protected $table ="accounts";

	function currency()
	{
		return $this->belongsTo('App\Models\Currency', 'currency_id');
	}
	
	function credits()
	{
		return $this->hasMany('App\Models\Credit', 'account_id');
	}
	
	function debits()
	{
		return $this->hasMany('App\Models\Debit', 'account_id');
	}
	

}